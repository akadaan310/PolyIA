import { CommandClient, ProtocolError } from './client.mjs';

const client = new CommandClient();
const $ = id => document.getElementById(id);
const json = value => JSON.stringify(value, null, 2);
let session = 0;
let live = false;
let working = false;
let refreshing = null;
let renderedHead = null;
let eventCursor = 0;
let loadedEvents = [];
let loadingEvents = false;

function node(tag, text = '', className = '') {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  return element;
}

function badge(status) {
  const color = ['ACCEPTED', 'APPLIED', 'PASS'].includes(status) ? 'green'
    : ['VERIFIED', 'ACKNOWLEDGED'].includes(status) ? 'blue'
    : ['PRODUCED', 'SUBMITTED', 'DEFERRED', 'PAUSED'].includes(status) ? 'amber'
    : ['REJECTED', 'FAIL', 'ERROR', 'REFUSED'].includes(status) ? 'red' : 'neutral';
  return node('span', status || 'UNKNOWN', 'badge badge-' + color);
}

function options(select, choices, emptyText) {
  const previous = select.value;
  const items = choices.map(([value, title]) => {
    const option = node('option', title);
    option.value = value;
    return option;
  });
  if (!items.length) { const empty = node('option', emptyText); empty.value = ''; items.push(empty); }
  select.replaceChildren(...items);
  if (choices.some(([value]) => value === previous)) select.value = previous;
}

function connection(label, mode = '') {
  $('connection-label').textContent = label;
  $('connection-status').className = 'connection-status' + (mode ? ' ' + mode : '');
}

function clearMessage() {
  $('error-banner').hidden = true;
  $('notice').hidden = true;
}

function showError(error) {
  if (error.code === 'SESSION_CHANGED') return;
  $('notice').hidden = true;
  $('error-title').textContent = error.code || 'REQUEST_ERROR';
  let message = error.message || 'The request could not be completed.';
  if (error.code === 'REVISION_CONFLICT') message += ' State has been refreshed. Review it, then submit your intended command again.';
  if (error.requestId) message += ' Request reference: ' + error.requestId + '.';
  $('error-message').textContent = message;
  $('error-details').textContent = error.details ? json(error.details) : '';
  $('error-details').hidden = !error.details;
  $('error-banner').hidden = false;
}

function notice(message) {
  $('notice').textContent = message;
  $('notice').hidden = false;
}

function canCommand() {
  return client.connected && live && client.scope === 'operator' && !working && !client.hasPending;
}

function updateControls() {
  const read = client.connected;
  const command = canCommand();
  document.querySelectorAll('[data-read]').forEach(element => { element.disabled = !read; });
  document.querySelectorAll('[data-command], [data-command-input]').forEach(element => { element.disabled = !command; });
  $('disconnect-button').disabled = !read && !working;
  const requirement = client.state?.requirements[$('requirement-select').value];
  $('verify-requirement').disabled = !command || !requirement?.artifacts?.length;
  $('accept-requirement').disabled = !command || requirement?.status !== 'VERIFIED';
  const guidance = client.state?.guidance[$('guidance-select').value];
  $('apply-guidance').disabled = !command || guidance?.status !== 'ACKNOWLEDGED' || !guidance.action;
  const closed = !guidance || ['APPLIED', 'REJECTED'].includes(guidance.status);
  $('ack-form').querySelector('button[type="submit"]').disabled = !command || closed;
  $('guidance-disposition').disabled = !command || closed;
  $('guidance-reason').disabled = !command || closed;
  $('run-experiment').disabled = !command || Boolean(client.state?.research?.paused);
  $('load-checkpoint').disabled = !read || !client.state?.latest_checkpoint;
  $('retry-panel').hidden = !client.hasPending;
  $('retry-command').disabled = working || !read || client.scope !== 'operator';
  $('retry-text').textContent = client.hasPending
    ? 'The result of ' + client.pendingId + ' is unresolved. Recover its receipt with the exact same request.' : '';
}

function renderRequirements() {
  const query = $('requirement-search').value.toLowerCase().trim();
  const status = $('requirement-filter').value;
  const requirements = Object.values(client.state?.requirements || {});
  const filtered = requirements.filter(item => (!status || item.status === status)
    && (!query || [item.id, item.title, item.verifier].join(' ').toLowerCase().includes(query)));
  const rows = filtered.map(item => {
    const row = document.createElement('tr');
    const title = document.createElement('td');
    title.append(node('span', item.id, 'requirement-id'), node('div', item.title, 'requirement-title'));
    const state = document.createElement('td'); state.append(badge(item.status));
    const priority = node('td', String(item.priority), 'mono');
    const action = document.createElement('td');
    const inspect = node('button', '↗', 'table-button');
    inspect.type = 'button'; inspect.setAttribute('aria-label', 'Inspect ' + item.id);
    inspect.addEventListener('click', () => { $('requirement-select').value = item.id; renderSelectedRequirement(); $('requirement-select').focus(); });
    action.append(inspect); row.append(title, state, priority, action); return row;
  });
  if (!rows.length) {
    const row = document.createElement('tr');
    const cell = node('td', client.state ? 'No obligations match this filter.' : 'Connect to view the constitution’s obligations.', 'empty-cell');
    cell.colSpan = 4; row.append(cell); rows.push(row);
  }
  $('requirements-body').replaceChildren(...rows);
  $('requirements-caption').textContent = client.state ? filtered.length + ' of ' + requirements.length + ' obligations shown' : 'No obligations loaded';
}

function renderSelectedRequirement() {
  const requirement = client.state?.requirements[$('requirement-select').value];
  $('selected-requirement-title').textContent = requirement?.title || 'Select an obligation to inspect its evidence.';
  $('selected-requirement-meta').textContent = requirement
    ? requirement.status + ' · Verifier: ' + requirement.verifier + ' · Priority ' + requirement.priority : '';
  $('requirement-detail').textContent = requirement ? json(requirement) : 'No obligation selected.';
  updateControls();
}

function renderSelectedGuidance() {
  const guidance = client.state?.guidance[$('guidance-select').value];
  const preview = $('guidance-preview');
  if (!guidance) {
    preview.replaceChildren(node('p', 'Submitted text and its registered action appear here.', 'muted'));
    $('guidance-detail').textContent = 'No guidance selected.';
    $('guidance-apply-help').textContent = 'Apply becomes available for acknowledged guidance with a registered action.';
  } else {
    preview.replaceChildren(badge(guidance.status), node('p', guidance.text),
      node('p', guidance.action ? 'Action: ' + JSON.stringify(guidance.action) : 'Text only · no executable action', 'mono'));
    $('guidance-detail').textContent = json(guidance);
    $('guidance-apply-help').textContent = guidance.status === 'APPLIED'
      ? 'Applied at revision ' + guidance.applied_revision + '. Exact effects are retained in the record.'
      : !guidance.action ? 'This guidance records text only. It cannot be labelled applied.'
      : guidance.status === 'ACKNOWLEDGED' ? 'Acknowledged. Applying will execute only the registered action shown above.'
      : 'Record an acknowledgment before applying the registered action.';
  }
  updateControls();
}

function renderRuns() {
  const runs = client.state?.runs || [];
  $('run-total').textContent = client.state ? runs.length + ' recorded' : '0 loaded';
  const list = runs.slice(-20).reverse().map(run => {
    const article = node('article', '', 'record-item');
    const top = node('div', '', 'record-top');
    top.append(node('strong', run.name), badge(run.report?.status));
    const caption = node('p', 'Revision ' + run.revision + ' · ' + (run.report?.evidence_class || 'No evidence class'), 'mono');
    const detail = document.createElement('details');
    detail.append(node('summary', 'Inputs, checks, code identity & limitations'), node('pre', json(run)));
    article.append(top, caption, detail); return article;
  });
  if (!list.length) list.push(node('p', client.state ? 'No experiments have been recorded.' : 'Connect to view recorded experiments and their limitations.', 'empty-state'));
  $('runs-list').replaceChildren(...list);
}

function renderState(force = false) {
  const state = client.state;
  if (!state) { renderDisconnected(); return; }
  $('revision').textContent = String(state.revision);
  $('head-short').textContent = 'head ' + state.head.slice(0, 15) + '…';
  $('head-short').title = state.head;
  $('mission-status').textContent = state.commission_status === 'NOT_COMMISSIONED' ? 'Not commissioned' : state.commission_status;
  const requirements = Object.values(state.requirements);
  const guidance = Object.values(state.guidance);
  const accepted = requirements.filter(item => item.status === 'ACCEPTED').length;
  $('accepted-count').textContent = String(accepted);
  $('requirement-total').textContent = '/ ' + requirements.length;
  $('acceptance-progress').max = Math.max(1, requirements.length);
  $('acceptance-progress').value = accepted;
  $('acceptance-caption').textContent = accepted + ' accepted · scoped evidence';
  $('pending-guidance').textContent = String(guidance.filter(item => ['SUBMITTED', 'DEFERRED'].includes(item.status)).length);
  $('guidance-caption').textContent = guidance.length + ' recorded · ' + guidance.filter(item => item.status === 'APPLIED').length + ' applied';
  $('research-state').textContent = state.research.paused ? 'Paused' : 'Active';
  $('research-badge').textContent = state.research.paused ? 'Paused by guidance' : 'Available';
  $('research-badge').className = 'badge ' + (state.research.paused ? 'badge-amber' : 'badge-green');
  $('runs-count').textContent = state.runs.length + ' recorded scientific runs';
  $('latest-checkpoint').textContent = state.latest_checkpoint
    ? state.latest_checkpoint.id + ' · revision ' + state.latest_checkpoint.revision + (state.latest_checkpoint.note ? ' · ' + state.latest_checkpoint.note : '')
    : 'No checkpoint has been created.';
  $('scope-display').textContent = client.scope === 'operator' ? 'Operator · reads + commands' : 'Read access only';
  $('session-description').textContent = client.scope === 'operator'
    ? 'Operator connected. Commands record the current revision and return a receipt.'
    : 'Read access connected. State, evidence, receipts, and verification are available.';
  if (force || renderedHead !== state.head) {
    options($('requirement-select'), requirements.map(item => [item.id, item.id + ' · ' + item.title]), 'No obligations');
    options($('guidance-target'), [['research', 'Research program'], ...requirements.map(item => [item.id, item.id + ' · ' + item.title])], 'No targets');
    options($('guidance-select'), guidance.sort((a, b) => b.submitted_revision - a.submitted_revision)
      .map(item => [item.id, item.status + ' · ' + item.target + ' · ' + item.text.slice(0, 60)]), 'No guidance recorded');
    $('guidance-queue-count').textContent = guidance.length + ' recorded';
    renderRequirements(); renderSelectedRequirement(); renderSelectedGuidance(); renderRuns();
    renderedHead = state.head;
  }
  updateControls();
}

function renderDisconnected() {
  renderedHead = null; loadedEvents = []; eventCursor = 0;
  ['revision', 'accepted-count', 'pending-guidance', 'research-state'].forEach(id => { $(id).textContent = '—'; });
  $('head-short').textContent = 'Connect to read state'; $('head-short').removeAttribute('title');
  $('requirement-total').textContent = ''; $('acceptance-progress').value = 0;
  $('acceptance-caption').textContent = 'Awaiting ledger state';
  $('guidance-caption').textContent = 'Submit · acknowledge · apply';
  $('runs-count').textContent = 'Registered exact functions only';
  $('last-refresh').textContent = 'No state received'; $('scope-display').textContent = 'No access scope';
  $('session-description').textContent = 'Enter an operator or read token. It stays in this tab’s memory.';
  $('research-badge').textContent = 'Awaiting state'; $('research-badge').className = 'badge badge-neutral';
  $('latest-checkpoint').textContent = 'No snapshot loaded.';
  $('verification-status').textContent = 'No verification requested in this session.';
  $('guidance-queue-count').textContent = 'No guidance';
  options($('requirement-select'), [], 'Connect first');
  options($('guidance-target'), [['research', 'Research program']], 'Connect first');
  options($('guidance-select'), [], 'No guidance recorded');
  for (const id of ['receipt-output', 'checkpoint-output', 'verification-output', 'refusals-output', 'event-output']) $(id).textContent = 'No record loaded in this session.';
  $('receipt-id').value = '';
  renderRequirements(); renderSelectedRequirement(); renderSelectedGuidance(); renderRuns(); renderEvents(); updateControls();
}

function renderEvents() {
  const rows = loadedEvents.slice().reverse().map(event => {
    const row = document.createElement('tr');
    const action = document.createElement('td');
    const inspect = node('button', '↗', 'table-button'); inspect.type = 'button';
    inspect.setAttribute('aria-label', 'Inspect event at revision ' + event.sequence);
    inspect.addEventListener('click', () => { $('event-output').textContent = json(event); $('event-details').open = true; });
    action.append(inspect);
    row.append(node('td', '#' + event.sequence, 'mono'), node('td', event.kind, 'mono'),
      node('td', event.actor), node('td', new Date(event.timestamp).toLocaleString(), 'mono'), action);
    return row;
  });
  if (!rows.length) {
    const row = document.createElement('tr');
    const cell = node('td', client.state ? 'No committed events loaded.' : 'Committed events appear after connection. Refusals are separate.', 'empty-cell');
    cell.colSpan = 5; row.append(cell); rows.push(row);
  }
  $('events-body').replaceChildren(...rows);
  $('event-cursor').textContent = client.state ? 'Cursor ' + eventCursor + ' · state revision ' + client.state.revision : 'Cursor —';
}

async function loadEvents() {
  if (!client.connected || loadingEvents) return;
  loadingEvents = true;
  const epoch = session;
  try {
    const feed = await client.read('/v1/events?after=' + eventCursor + '&limit=100');
    if (epoch !== session) return;
    if (!Array.isArray(feed.events) || !Number.isInteger(feed.next_after)) throw new ProtocolError('INVALID_RESPONSE', 'The event feed returned an invalid cursor.');
    loadedEvents = [...loadedEvents, ...feed.events].slice(-100);
    eventCursor = feed.next_after;
    renderEvents();
  } finally { loadingEvents = false; }
}

async function sync() {
  if (!client.connected) return;
  if (refreshing) return refreshing;
  const epoch = session;
  refreshing = (async () => {
    try {
      const previous = client.state;
      await client.refresh();
      if (epoch !== session) return;
      if (previous && client.state.revision < previous.revision) {
        loadedEvents = []; eventCursor = 0;
        notice('The service is reporting an earlier revision. Event polling restarted from the beginning; inspect the ledger before issuing commands.');
      }
      live = true; connection(document.hidden ? 'Connected · polling paused' : 'Connected · live', 'connected');
      renderState();
      $('last-refresh').textContent = 'State received ' + new Date().toLocaleTimeString();
      await loadEvents();
    } catch (error) {
      if (epoch !== session) return;
      live = false; connection('Connection needs attention', 'stale'); updateControls(); showError(error);
    } finally { if (epoch === session) refreshing = null; }
  })();
  return refreshing;
}

async function runRead(path, target, detail, label) {
  const epoch = session;
  clearMessage();
  try {
    const result = await client.read(path);
    if (epoch !== session) return;
    $(target).textContent = json(result); $(detail).open = true;
    if (label === 'verification') {
      $('verification-status').textContent = result.ok ? 'Verification passed for the checked ledger, artifacts, and checkpoints.' : 'Verification found a problem. Inspect the diagnostics; no repair was applied.';
      if (!result.ok) showError(new ProtocolError('INTEGRITY_FAILURE', 'Ledger verification reported a failure.', 200, result));
    }
  } catch (error) { if (epoch === session) showError(error); }
}

async function execute(kind, payload, retry = false) {
  if (working) return;
  const epoch = session;
  clearMessage(); working = true; updateControls();
  try {
    const receipt = retry ? await client.retry() : await client.command(kind, payload);
    if (epoch !== session) return;
    $('receipt-output').textContent = json(receipt); $('receipt-details').open = true;
    $('receipt-id').value = receipt.command_id;
    let outcome = '';
    if (receipt.result?.verification) outcome = ' Verifier outcome: ' + receipt.result.verification.outcome + '.';
    if (receipt.result?.run) outcome = ' Scientific result: ' + receipt.result.run.report.status + '. Inspect its evidence class and limitations.';
    notice('Command recorded at revision ' + receipt.revision + '. Receipt: ' + receipt.command_id + '.' + outcome);
  } catch (error) {
    if (epoch === session) showError(error);
  } finally {
    if (epoch === session) {
      working = false;
      if (refreshing) await refreshing;
      await sync(); updateControls();
    }
  }
}

function form(id, handler) {
  $(id).addEventListener('submit', event => {
    event.preventDefault();
    Promise.resolve().then(handler).catch(showError);
  });
}

form('connect-form', async () => {
  const token = $('token').value; $('token').value = '';
  const epoch = ++session;
  clearMessage(); live = false; working = false; renderedHead = null; refreshing = null; loadingEvents = false;
  loadedEvents = []; eventCursor = 0;
  $('connect-button').disabled = true; connection('Connecting…');
  try {
    await client.connect(token);
    if (epoch !== session) return;
    live = true; renderState(true); connection('Connected · live', 'connected');
    $('last-refresh').textContent = 'State received ' + new Date().toLocaleTimeString();
    await loadEvents();
  } catch (error) {
    if (epoch === session) { live = false; connection('Disconnected'); renderDisconnected(); showError(error); }
  } finally {
    if (epoch === session) { $('connect-button').disabled = false; updateControls(); }
  }
});

$('disconnect-button').addEventListener('click', () => {
  session += 1; client.disconnect(); live = false; working = false; refreshing = null; loadingEvents = false;
  $('token').value = ''; $('connect-button').disabled = false; clearMessage(); connection('Disconnected'); renderDisconnected();
});
$('dismiss-error').addEventListener('click', () => { $('error-banner').hidden = true; });
$('refresh-button').addEventListener('click', () => { clearMessage(); sync(); });
$('requirement-search').addEventListener('input', renderRequirements);
$('requirement-filter').addEventListener('change', renderRequirements);
$('requirement-select').addEventListener('change', renderSelectedRequirement);
$('guidance-select').addEventListener('change', renderSelectedGuidance);
$('guidance-action').addEventListener('change', () => {
  const action = $('guidance-action').value;
  $('priority-field').hidden = action !== 'set_priority';
  if (['pause_research', 'resume_research'].includes(action)) $('guidance-target').value = 'research';
});

form('produce-form', () => execute('requirement.produce', {
  requirement_id: $('requirement-select').value,
  artifacts: $('artifact-paths').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean), note: $('production-note').value,
}));
$('verify-requirement').addEventListener('click', () => execute('requirement.verify', { requirement_id: $('requirement-select').value }));
$('accept-requirement').addEventListener('click', () => execute('requirement.accept', { requirement_id: $('requirement-select').value }));
form('guidance-form', () => {
  const target = $('guidance-target').value;
  const payload = { target, text: $('guidance-text').value };
  const kind = $('guidance-action').value;
  if (kind === 'set_priority') {
    if (target === 'research') throw new ProtocolError('TARGET_REQUIRED', 'Choose an obligation target before setting its priority.');
    const priority = Number($('guidance-priority').value);
    if (!Number.isInteger(priority) || priority < 0 || priority > 9) throw new ProtocolError('INVALID_PRIORITY', 'Priority must be an integer from 0 through 9.');
    payload.action = { kind, target, priority };
  } else if (kind) {
    if (target !== 'research') throw new ProtocolError('TARGET_REQUIRED', 'Pause and resume actions require the research program target.');
    payload.action = { kind };
  }
  return execute('guidance.submit', payload);
});
form('ack-form', () => execute('guidance.ack', {
  guidance_id: $('guidance-select').value, disposition: $('guidance-disposition').value, reason: $('guidance-reason').value,
}));
$('apply-guidance').addEventListener('click', () => execute('guidance.apply', { guidance_id: $('guidance-select').value }));
form('experiment-form', () => {
  let parameters;
  try { parameters = JSON.parse($('experiment-parameters').value); } catch (_) {
    throw new ProtocolError('INVALID_PARAMETERS', 'Experiment parameters must be a valid JSON object.');
  }
  if (!parameters || typeof parameters !== 'object' || Array.isArray(parameters)) throw new ProtocolError('INVALID_PARAMETERS', 'Experiment parameters must be a JSON object.');
  return execute('experiment.run', { name: $('experiment-name').value, parameters });
});
form('checkpoint-form', () => execute('checkpoint.create', { note: $('checkpoint-note').value }));
$('load-checkpoint').addEventListener('click', () => runRead('/v1/checkpoints/latest', 'checkpoint-output', 'checkpoint-details'));
$('verify-ledger').addEventListener('click', () => runRead('/v1/verify', 'verification-output', 'verification-details', 'verification'));
form('receipt-form', () => runRead('/v1/commands/' + encodeURIComponent($('receipt-id').value.trim()), 'receipt-output', 'receipt-details'));
$('load-refusals').addEventListener('click', () => runRead('/v1/refusals?limit=25', 'refusals-output', 'refusals-details'));
$('load-events').addEventListener('click', () => loadEvents().catch(showError));
$('retry-command').addEventListener('click', () => execute(null, null, true));

setInterval(() => { if (!document.hidden && !working) sync(); }, 4000);
document.addEventListener('visibilitychange', () => {
  if (!client.connected) return;
  if (document.hidden) connection('Connected · polling paused', live ? 'connected' : 'stale');
  else sync();
});
window.addEventListener('pagehide', () => {
  session += 1; client.disconnect(); live = false; working = false; refreshing = null; loadingEvents = false;
  $('token').value = ''; $('connect-button').disabled = false; clearMessage(); connection('Disconnected'); renderDisconnected();
});
renderDisconnected();
