#!/usr/bin/env python3
"""Audit the *new bootstrap runtime*, not inert preserved upstream archives."""
import ast
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import sys
import urllib.request
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))

def audit():
    errors=[]; modules=[]; imports=[]
    for path in sorted((ROOT/'polyia').glob('*.py')):
        raw=path.read_bytes(); tree=ast.parse(raw,filename=str(path))
        modules.append({'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest()})
        for node in ast.walk(tree):
            names=[]
            if isinstance(node,ast.Import):names=[n.name.split('.')[0] for n in node.names]
            elif isinstance(node,ast.ImportFrom) and not node.level:names=[(node.module or '').split('.')[0]]
            for name in names:
                imports.append(name)
                if name not in sys.stdlib_module_names and name!='polyia':errors.append(f'Non-stdlib runtime dependency: {name} in {path.name}')
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in {'eval','exec','__import__'}:
                errors.append(f'Unbounded code-execution primitive: {node.func.id} in {path.name}')
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='_code_identity':
                if not node.args or not isinstance(node.args[0],ast.Constant) or node.args[0].value not in {'polyia.store','polyia.experiments'}:
                    errors.append(f'Unregistered module-identity import in {path.name}')
    weights=[str(p.relative_to(ROOT)) for p in (ROOT/'polyia').rglob('*') if p.suffix.lower() in {'.gguf','.pt','.pth','.safetensors','.onnx','.h5'}]
    if weights:errors.append('Unexpected model artifacts in runtime: '+','.join(weights))
    from polyia.experiments import run_registered
    def denied(*args,**kwargs):raise AssertionError('Offline kernel attempted a denied network/process operation')
    with patch.object(socket,'socket',denied),patch.object(subprocess,'Popen',denied),patch.object(urllib.request,'urlopen',denied):
        result=run_registered('acceptance',{})
    if result['status']!='PASS' or not result['checks'] or not all(c['pass'] for c in result['checks']):errors.append('Offline exact-kernel acceptance failed')
    return {'ok':not errors,'scope':'new stdlib bootstrap modules and registered exact scientific kernels',
            'runtime_modules':modules,'imports':sorted(set(imports)),'model_artifacts':weights,'offline_checks':result['checks'],
            'errors':errors,'limitations':['Static imports plus intercepted kernel execution establish this finite bootstrap scope, not every future plugin.',
             'Archived upstream source is retained data, not imported into the running baseline.',
             'The fixed installed scientific module is compiled only to compare its code structure with loaded functions; that comparison object is never executed.',
             'The HTTP service necessarily uses a loopback socket; this audit disables networking for the scientific kernels.',
             'Full commission requires the broader no-inference process/tool/model-artifact gate as capabilities are added.']}

if __name__=='__main__':
    report=audit();print(json.dumps(report,indent=2));sys.exit(0 if report['ok'] else 1)
